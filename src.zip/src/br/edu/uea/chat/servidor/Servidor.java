package br.edu.uea.chat.servidor;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import br.edu.uea.chat.control.UsuarioController;
import br.edu.uea.chat.control.MensagemController;

/**
 * Esta classe serve para estabelecer conexão com uma porta, de modo a permitir a comunicação entre usuários pela porta 5000
 * Essa versão abre a porta 5000, espera uma conexão com cliente (ClienteThread),
 * inicia a thread e fecha as conexões ao finalizar o servidor
 * @version 3.1 (corrigido: clientes online só são adicionados após login)
 */

public class Servidor extends Thread{
	private static final int PORTA = 5000;
	private ServerSocket serverSocket;

	private UsuarioController usuarioController;
	private MensagemController mensagemController;

	private static ArrayList<ClienteThread> clientesOnline = new ArrayList<>();
	
	public Servidor() {
		this.usuarioController = new UsuarioController();
		this.mensagemController = new MensagemController();
	}
	
	public void run(){
		try {
			serverSocket = new ServerSocket(PORTA);
			System.out.println("Servidor iniciado na porta " + PORTA);
			
			while (true) {
	            System.out.println("Aguardando conexão...");
	            Socket connection = serverSocket.accept();

	            System.out.println("Cliente conectado: "+ connection.getInetAddress().getHostName());
	            
	            ClienteThread clienteThread = new ClienteThread(connection, this);
	            clienteThread.start();
	        }
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public UsuarioController getUsuarioController() {
		return this.usuarioController;
	}

	public MensagemController getMensagemController() {
		return this.mensagemController;
	}
	
	public void close() throws IOException {
		if(serverSocket != null) {
			serverSocket.close();
			System.out.println("Fechando conexões.");
		}
	}

	public static ArrayList<ClienteThread> getClientesOnline(){
		return clientesOnline;
	}

	public static void addClienteOnline(ClienteThread clienteOnline){
		clientesOnline.add(clienteOnline);
	}

	public static void removeClienteOnline(ClienteThread clienteOnline){
		clientesOnline.remove(clienteOnline);
	}
}